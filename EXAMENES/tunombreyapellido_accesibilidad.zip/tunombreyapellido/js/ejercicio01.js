

function register() {
 alert("Registrado con éxito, pero este mensaje no es accesible.");
}
