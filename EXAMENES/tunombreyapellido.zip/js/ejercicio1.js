var todolist = new Vue({

 el:"#todolist",
 data:{
  nuevaTarea:"",
  listaTareas:[],
  visibilidad:"todas"
 },
 computed:{
  tareasFiltradas(){
   //INTRODUCIR EL CÓDIGO NECESARIO
  },
  tareasPendientes(){
   //INTRODUCIR EL CÓDIGO NECESARIO
  }
 },
 methods:{
  agregarTarea() {
   //INTRODUCIR EL CÓDIGO NECESARIO
   // Registra la fecha y hora actual
  },
  setVisibilidad(estadoVisibilidad){
   //INTRODUCIR EL CÓDIGO NECESARIO
  },
  toggleCompletada(id) {
   //INTRODUCIR EL CÓDIGO NECESARIO
   // Registra la fecha de completado
   // Resetea la fecha de completado si se desmarca
  }
 }

})


