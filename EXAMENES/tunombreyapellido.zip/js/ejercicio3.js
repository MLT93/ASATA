document.getElementById('btnLimpiar').addEventListener('click', function() {



 // Selecciona el formulario por su id y lo resetea
 document.getElementById('formularioAvanzado').reset();
 // Opcional: Limpia cualquier mensaje de error visible
 const divErrores = document.getElementById("errores");

 
 if (divErrores) {
  divErrores.innerHTML = "";
  divErrores.style.display = "none";
  divErrores.style.visibility = "hidden"; // Oculta el div de errores
 }


 const inputs = document.querySelectorAll('input, select, textarea');
 inputs.forEach(input => {
   //INTRODUCIR EL CÓDIGO NECESARIO
   // Opcional: Restablece el estilo de los campos del formulario
 });
});

document.getElementById('formularioAvanzado').addEventListener('submit', function(event) {
 event.preventDefault(); // Prevenir el envío estándar del formulario

 try {
    
     const inputs = document.querySelectorAll('input, select, textarea');
     inputs.forEach(input => {
      //INTRODUCIR EL CÓDIGO NECESARIO
      // para resetear el formato de todos los inputs
     });

     // Validación de cada campo según los requisitos
     validarCampo('nombre', "El nombre es obligatorio");
     validarMayorEdad('fechaNacimiento', "Debes ser mayor de edad para registrarte.");
     validarTelefono('telefono', "El número de teléfono no es válido.");

     validarEmail('email', "El correo electrónico no es válido.");
     validarCampo('direccion', "La dirección es obligatoria");
     validarCampo('ciudad', "La ciudad es obligatoria");
     validarCampo('region', "La región es obligatoria");
     validarSeleccion('pais', "Seleccionar un país es obligatorio");

     validarURL('sitioWeb', "La URL del sitio web personal no es válida.");
     validarCheckbox('formacion', "Seleccionar al menos una opción de formación es obligatorio");
     validarCampo('intereses', "Los intereses son obligatorios");


     alert("Formulario enviado con éxito.");
     console.log("Formulario válido. Implementar envío del formulario.");

 } catch (error) {
     const divErrores = document.getElementById("errores");
     divErrores.innerHTML = `<p>${error.msj}</p>`;
     divErrores.style.display = "block"; // Muestra el div de errores
     divErrores.style.visibility = "visible"; // Muestra el div de errores
     error.elemento.style.borderColor = "red";
     error.elemento.focus();
 }
});

function validarCampo(id, mensajeError) {
   //INTRODUCIR EL CÓDIGO NECESARIO
}

function validarEmail(id, mensajeError) {
   //INTRODUCIR EL CÓDIGO NECESARIO
}

function validarSeleccion(id, mensajeError) {
   //INTRODUCIR EL CÓDIGO NECESARIO
}

function validarCheckbox(nombre, mensajeError) {
   //INTRODUCIR EL CÓDIGO NECESARIO
}

function validarTelefono(id, mensajeError) {
   //INTRODUCIR EL CÓDIGO NECESARIO
}

function validarMayorEdad(id, mensajeError) {
   //INTRODUCIR EL CÓDIGO NECESARIO
}

function validarURL(id, mensajeError) {
   //INTRODUCIR EL CÓDIGO NECESARIO
}