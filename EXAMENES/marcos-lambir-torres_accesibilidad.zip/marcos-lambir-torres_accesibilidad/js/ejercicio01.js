document.addEventListener("DOMContentLoaded", () => {
  const buttonSubmit_HTML = document.getElementById("buttonSubmit");

  buttonSubmit_HTML.onclick = function () {
    alert("Registrado con éxito.");
  };
});
