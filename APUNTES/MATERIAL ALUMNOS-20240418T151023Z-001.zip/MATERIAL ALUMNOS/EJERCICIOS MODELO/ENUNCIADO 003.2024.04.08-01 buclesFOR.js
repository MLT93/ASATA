// Sumar los números del 1 al 100
// Usa un bucle for para sumar los números del 1 al 100.
// Función ad hoc: sumarNumeros.
function sumarNumeros() {
  let suma = 0;
  for (let i = 1; i <= 100; i++) {
    suma += i;
  }
  console.log(suma);
  return suma;
}
sumarNumeros();



// Multiplica los 10 primeros números naturales (1 al 10).
// Función ad hoc: multiplicarNumeros.
function multiplicarNumeros() {
//*******************************  ESCRIBE A CONTINUACIÓN TU CÓDIGO PARA RESOLVER EL EJC *********************************/
}
//*******************************  ESCRIBE A CONTINUACIÓN LA INVOCACIÓN DE LA FUNCIÓN ************************************/



// Listar los números pares del 0 al 50
// Usa un bucle for para imprimir los números pares del 0 al 50.
// Función ad hoc: listarPares.
function listarPares() {
//*******************************  ESCRIBE A CONTINUACIÓN TU CÓDIGO PARA RESOLVER EL EJC *********************************/
}
//*******************************  ESCRIBE A CONTINUACIÓN LA INVOCACIÓN DE LA FUNCIÓN ************************************/



// Genera un array con los cuadrados de los primeros 10 números enteros.
// Función ad hoc: generarCuadrados.
function generarCuadrados() {
//*******************************  ESCRIBE A CONTINUACIÓN TU CÓDIGO PARA RESOLVER EL EJC *********************************/
}
//*******************************  ESCRIBE A CONTINUACIÓN LA INVOCACIÓN DE LA FUNCIÓN ************************************/


// Contar cuántas veces aparece una letra en una cadena
// Dada una cadena y una letra, cuenta cuántas veces aparece la letra en la cadena.
// Función ad hoc: contarLetra.
function contarLetra(cadena, letra) {
  let contador = 0;
  for (let i = 0; i < cadena.length; i++) {
    if (cadena[i] === letra) {
      contador++;
    }
  }
  console.log(contador);
  return contador;
}
contarLetra("hola mundo", "o");


// Escribe una función que tome una cadena como argumento y devuelva esa cadena invertida. Por ejemplo, si pasas la cadena "hola", la función debería devolver "aloh".
function invertirCadena(cadena) {
//*******************************  ESCRIBE A CONTINUACIÓN TU CÓDIGO PARA RESOLVER EL EJC *********************************/
}
//*******************************  ESCRIBE A CONTINUACIÓN LA INVOCACIÓN DE LA FUNCIÓN ************************************/


// Crea una función que reciba una cadena y devuelva el número total de vocales (a, e, i, o, u) que contiene esa cadena, sin importar si son mayúsculas o minúsculas.
function contarVocales(cadena) {
//*******************************  ESCRIBE A CONTINUACIÓN TU CÓDIGO PARA RESOLVER EL EJC *********************************/
}
//*******************************  ESCRIBE A CONTINUACIÓN LA INVOCACIÓN DE LA FUNCIÓN ************************************/