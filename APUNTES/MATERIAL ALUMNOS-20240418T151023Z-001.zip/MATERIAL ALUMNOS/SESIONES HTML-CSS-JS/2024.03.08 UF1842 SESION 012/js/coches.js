// Sacar repetidamente un prompt por pantalla que pida al usuario la marca de un coche

// hasta que el usuario introduzca la palabra FINALIZAR


//Escribir el listado por pantalla

// var coches = [];
// var i = 0;


// while( coche != "fin" ){

//     var coche = prompt("Introduzca la marca de un coche");
//     coche = coche.toLowerCase();

//     console.log(coche);

//     if(coche != "fin"){
//         coche = coche.charAt(0).toUpperCase() + coche.slice(1);
//         coches[i] = coche;
//         i++;
//     }

// }

// console.log(coches);


// document.write("<h2>LISTA DE COCHES</h2>");

// for(var i = 0; i < coches.length;  i++){

// document.write(coches[i]+"</br>")    ;
// }


var x = 5;

for ( var x = 0; x < 9 ; x++){
    console.log(x);
}

console.log("Estoy fuera del bucle");
console.log(x);

console.log("************************************************************");


let y = 5;

for ( let y = 0; y < 9 ; y++){
    console.log(y);
}

console.log("Estoy fuera del bucle");
console.log(y);