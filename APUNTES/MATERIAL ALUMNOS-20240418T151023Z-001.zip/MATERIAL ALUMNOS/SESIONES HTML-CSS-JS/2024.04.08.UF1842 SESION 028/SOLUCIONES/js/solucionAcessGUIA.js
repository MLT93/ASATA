document.getElementById("more-info"). addEventListener('click', function() {
 alert('Más información');
});
