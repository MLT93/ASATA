// Se recomienda separar el comportamiento (JavaScript) del marcado (HTML)
document.querySelector('button').addEventListener('click', function() {
 alert('Información accesible.');
});
