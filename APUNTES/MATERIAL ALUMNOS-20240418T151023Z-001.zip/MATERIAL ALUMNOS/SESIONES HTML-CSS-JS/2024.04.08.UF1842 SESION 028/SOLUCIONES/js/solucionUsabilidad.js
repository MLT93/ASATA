

// Este script añade interactividad de manera accesible.
document.addEventListener('DOMContentLoaded', function() {
 document.querySelector('button').addEventListener('click', function() {
     alert('Has activado la información adicional de manera accesible.');
 });
});

