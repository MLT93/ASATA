
window.onload = function() {

 document.getElementById('btn').onclick = function() {
     alert('Has presionado el botón');
 };
};


