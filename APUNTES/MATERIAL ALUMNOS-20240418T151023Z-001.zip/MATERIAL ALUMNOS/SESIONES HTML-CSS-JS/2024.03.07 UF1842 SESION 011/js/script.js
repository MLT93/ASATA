// alert('Hola \n mundo');   

var numero1 = 3;
var numero2 = 2;
var suma;
var numTexto= "23";

numero1 = numero1.toString();

suma = numero1 + numero2;

// console.log(suma);
// console.log(numero1 + numTexto);
console.log(numero1 + numero2);

// hslfggflk

// f´l´lsdñfd´
// f
// dskfñlsdflds