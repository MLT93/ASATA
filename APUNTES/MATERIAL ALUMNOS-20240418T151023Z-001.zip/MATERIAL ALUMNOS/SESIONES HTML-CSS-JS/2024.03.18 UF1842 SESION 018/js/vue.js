var app = new Vue({

    el: '#app',
    data: {
        message: "Hola mundo"
    }

})