new Vue({

el:"#app",
methods:{

    mostrarMensaje: function(mensaje){
        console.log(mensaje);
    }

}

})