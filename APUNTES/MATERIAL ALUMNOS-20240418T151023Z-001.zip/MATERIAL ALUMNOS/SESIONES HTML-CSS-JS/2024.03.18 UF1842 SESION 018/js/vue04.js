new Vue({

el:'#app',
data: {

    nombres: ['Alice', "Bob", "Carol", "Dave" ]

}


})