new Vue({

    el:"#app",
    data:{
        mensaje:''
    }

})