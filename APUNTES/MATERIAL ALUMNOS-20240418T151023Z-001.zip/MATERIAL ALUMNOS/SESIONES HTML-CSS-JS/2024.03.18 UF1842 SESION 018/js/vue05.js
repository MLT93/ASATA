new Vue({

el:'#app',
data:{
    msj: "La página se cargo el " + new Date().toLocaleString()
}



})