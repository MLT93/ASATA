var vm = new Vue({

el:"#vm",
data:{
    colorFondo:"cyan",
    colorTexto: "blue"
}



})