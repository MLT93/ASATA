<?php

$cadena1 = "mi nombre es ";
$cadena2 = "Dario";


echo $cadena1.$cadena2;


$dia = 16;

echo "Hoy es dia ".$dia;echo "<br/>";
echo "Hoy es dia $dia";echo "<br/>";
echo 'Hoy es dia $dia';echo "<br/>";


?>