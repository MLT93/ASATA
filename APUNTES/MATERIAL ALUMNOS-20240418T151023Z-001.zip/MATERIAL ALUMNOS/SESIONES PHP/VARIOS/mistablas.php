<?php
include("../FUNCIONES/tablas.php");


// tabla(10,6);


$titulos = array(
    "id",
    "nombre",
    "apellido 1",
    "apellido 2",
    "pais",
    "edad"
);

tablaConTitulos($titulos, 20);


?>