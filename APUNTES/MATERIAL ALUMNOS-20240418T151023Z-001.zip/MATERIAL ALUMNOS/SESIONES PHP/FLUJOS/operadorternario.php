<?php

$var1 = 3;
$var2 = 5;
echo ($var1 > $var2) ? "var1 es mayor que var2" :"var2 es mayor que var1" ;



$palabra1 = "marta";
$palabra2 = "andrea";
echo ($palabra1 > $palabra2) ? "palabra1 esta despues de palabra2":"palabra1 esta antes de palabra2";

?>