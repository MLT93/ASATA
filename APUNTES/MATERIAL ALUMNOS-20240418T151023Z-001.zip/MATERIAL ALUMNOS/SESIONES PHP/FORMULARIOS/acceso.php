<!DOCTYPE html>
<html>
    <head>
        <title>ACCESO</title>       
    </head>
    <body>
        <h2>LOG</h2>

        <form action="resp_acceso.php" method="post">  


            <label for="nombreid">NOMBRE</label>
            <input type="text" name="nombre" id="nombreid">

            <label for="pass">PASSWORD</label>
            <input type="password" name="pass" id="pass">

            <input type="submit" name="enviar" value="Enviar">

        </form>

        </form>
    </body>
</html>